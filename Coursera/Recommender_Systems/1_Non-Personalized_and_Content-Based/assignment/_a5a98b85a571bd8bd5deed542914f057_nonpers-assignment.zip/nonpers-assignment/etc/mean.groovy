import org.lenskit.mooc.nonpers.mean.MeanItemBasedItemRecommender
import org.lenskit.api.ItemBasedItemRecommender

bind ItemBasedItemRecommender to MeanItemBasedItemRecommender
